export const MessageConstant = {
  Heading: "Wendy`s Voice Bot"
};

export const MenuItems = {
  keyWords: ["order", "search", "available", "find", "restaurent"],
  item: ["pizza", "burger", "coffee", "cub", "paneer"],
  Size: ["small", "medium", "large"]
};

export const BotReplies = {
  order: {
    isAddressPresent: "Please Give us a valid delivery address",
    isPickUpPoint: "Please select a pick up point",
    Success: "Your order is in its way",
    Failure: "Sorry !!, Something went wrong"
  },
  Menu: {
    notPresent: "No Such Word"
  },
  Payment: {
    isPending: "Please complete the payment"
  }
};
