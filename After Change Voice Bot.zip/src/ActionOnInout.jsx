import React from "react";
import "./styles.css";
import { MessageConstant, MenuItems, BotReplies } from "./constData.js";
import Speech from "speak-tts";

const speech = new Speech();
export const ActionOnInput = props => {
  let userInputArray = props.data.searchValue.split(" ");

  let map = new Map();
  userInputArray.forEach(element => {
    MenuItems.item.find(value => {
      element.toUpperCase() === value.toUpperCase()
        ? map.set("item", value)
        : "";
    });
    MenuItems.keyWords.find(value => {
      element.toUpperCase() === value.toUpperCase()
        ? map.set("Keywords", value)
        : "";
    });
    MenuItems.Size.find(value => {
      element.toUpperCase() === value.toUpperCase()
        ? map.set("Size", value)
        : "";
    });
  });

  if (map.get("item") != null || map.get("item") != "") {
    let speak =
      "We are Processing the operation " +
      map.get("Keywords") +
      "on" +
      map.get("item") +
      "with size" +
      map.get("Size");
    speech
      .speak({
        text: speak
      })
      .then(() => {
        console.log("Success !");
      })
      .catch(e => {
        console.error("An error occurred :", e);
      });
  }
  return (
    <div>
      {map.get("item") != null && map.get("item") != ""
        ? "You are ordering :- "
        : ""}
      {map.get("item")}
      <br />
      {map.get("Size") != null && map.get("Size") != ""
        ? "Selected Size :- "
        : ""}
      {map.get("Size")}
      <br />
      {map.get("Keywords") != null && map.get("Keywords") != ""
        ? "Operation Type:- "
        : ""}
      {map.get("Keywords")}
      <br />
      <br />
      {map.get("Keywords") != null && map.get("Keywords") != ""
        ? !map.get("item") && "No such Order"
        : ""}
    </div>
  );
};
